// /pages/news/[kategoriSlug]/index.tsx
import { GetServerSideProps } from "next";
import MiniHeader from "@/components/atoms/MiniHeader";
import ReadMore from "@/components/atoms/ReadMore";
import NewsContainer from "@/components/organism/NewsContiner";
import PageTemplates from "@/components/templates/PageTemplates";

interface Props {
    kategoriSlug: string;
}

export default function NewsByCategory({ kategoriSlug }: Props) {
    return (
        <PageTemplates title={kategoriSlug}>
            <MiniHeader title={kategoriSlug} />
            <NewsContainer kategoriSlug={kategoriSlug} />
            <div className="text-center">
                <ReadMore />
            </div>
        </PageTemplates>
    );
}

// Ambil params dari server supaya refresh nggak 404
export const getServerSideProps: GetServerSideProps = async (context) => {
    const { kategoriSlug } = context.params || {};

    if (!kategoriSlug || typeof kategoriSlug !== "string") {
        return {
            notFound: true, // Kalau slug tidak valid
        };
    }

    return {
        props: {
            kategoriSlug,
        },
    };
};
