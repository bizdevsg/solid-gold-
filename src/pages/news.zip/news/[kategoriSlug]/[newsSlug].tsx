import PageTemplates from "@/components/templates/PageTemplates";

export default function detail() {
    return (
        <PageTemplates>
            
        </PageTemplates>
    );
}