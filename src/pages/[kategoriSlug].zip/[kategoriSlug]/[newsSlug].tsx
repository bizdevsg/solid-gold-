// pages/berita/[newsSlug].tsx
import { useRouter } from "next/router";
import { useEffect, useMemo, useState } from "react";
import PageTemplates from "@/components/templates/PageTemplates";

interface Berita {
    id: number;
    title: string;
    slug: string;
    content: string;
    kategori?: { name: string };
    images?: string[];
    created_at?: string;
}

export default function BeritaDetailPage() {
    const router = useRouter();
    const rawSlug = router.query.newsSlug;

    // Pastikan slug berupa string
    const newsSlug = useMemo(() => {
        if (typeof rawSlug === "string") return rawSlug;
        if (Array.isArray(rawSlug)) return rawSlug[0];
        return undefined;
    }, [rawSlug]);

    const [berita, setBerita] = useState<Berita | null>(null);
    const [loading, setLoading] = useState(true);
    const [errMsg, setErrMsg] = useState<string | null>(null);

    useEffect(() => {
        if (!newsSlug) return;

        const ac = new AbortController();

        const fetchDetail = async () => {
            setLoading(true);
            setErrMsg(null);

            try {
                const res = await fetch(
                    `http://portal-backpanel.test/api/berita/${encodeURIComponent(newsSlug)}`,
                    { signal: ac.signal }
                );
                if (!res.ok) throw new Error(`Gagal mengambil data berita (status ${res.status})`);

                const result = await res.json();

                // JSON parser sudah mengubah \u003C \u003E \u0026 menjadi < > &
                // Jadi langsung pakai result.data.content apa adanya (TANPA replace & TANPA he.decode)
                const htmlContent: string = result?.data?.content ?? "";

                setBerita({
                    ...result.data,
                    content: htmlContent,
                });
            } catch (error: any) {
                if (error?.name !== "AbortError") {
                    console.error(error);
                    setErrMsg(error?.message || "Terjadi kesalahan saat memuat berita");
                    setBerita(null);
                }
            } finally {
                setLoading(false);
            }
        };

        fetchDetail();

        return () => ac.abort();
    }, [newsSlug]);

    if (loading) {
        return (
            <PageTemplates title="Loading...">
                <p>Memuat data...</p>
            </PageTemplates>
        );
    }

    if (errMsg) {
        return (
            <PageTemplates title="Terjadi Kesalahan">
                <p className="text-red-400">{errMsg}</p>
            </PageTemplates>
        );
    }

    if (!berita) {
        return (
            <PageTemplates title="Berita Tidak Ditemukan">
                <p>Berita tidak tersedia.</p>
            </PageTemplates>
        );
    }

    return (
        <PageTemplates title={berita.title}>
            <div className="text-center mb-6">
                {berita.kategori?.name && (
                    <p className="text-yellow-500 font-semibold mb-2">
                        {berita.kategori.name} News
                    </p>
                )}

                <h1 className="text-3xl font-bold text-white mb-2">{berita.title}</h1>

                {berita.created_at && (
                    <p className="text-gray-400 text-sm">
                        {new Date(berita.created_at).toLocaleDateString("id-ID", {
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                        })}
                    </p>
                )}
            </div>

            {berita.images?.[0] && (
                <img
                    src={`http://portal-backpanel.test/${berita.images[1]}`}
                    alt={berita.title}
                    className="w-full max-h-[400px] object-cover rounded-lg mb-6"
                    loading="lazy"
                />
            )}

            {/* Konten berita */}
            <div
                className="prose prose-invert max-w-none"
                dangerouslySetInnerHTML={{ __html: berita.content }}
            />
        </PageTemplates>
    );
}
